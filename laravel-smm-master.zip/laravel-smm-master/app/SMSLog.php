<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SMSLog extends Model
{
    protected $table = "sms_message";
}
