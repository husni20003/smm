<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Deposit_method extends Model
{
    //
}
